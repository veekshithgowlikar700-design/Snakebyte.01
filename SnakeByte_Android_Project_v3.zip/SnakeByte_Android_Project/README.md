# SnakeByte 🐍

SnakeByte is a Python learning Android app built as a WebView project.

## Changes in this version
- Renamed the app to **SnakeByte**.
- Added a clean first-launch name/login screen.
- Fixed small-screen header/text crowding and login layout overlap.
- Added light/dark mode with the choice saved on the device.
- Added automatic progression: after completing a lesson/coding mission, SnakeByte opens the next lesson automatically.
- Course/world progression remains locked until the previous lesson/world is completed.
- Preserves existing progress stored in `localStorage`.
- Added a GitHub Actions workflow that builds a debug APK automatically.

## v3 changes
- Brand-new iOS-style minimal UI (light/dark), smooth and lightweight.
- All 142 levels are typed-code challenges, getting harder every level; the last level of each world is a Boss.
- 3 chances per level. After every level: Next level / Retry / Home.
- Max 3 hints per level, each costs XP. No hints on Boss levels.
- Python runs off the main thread with a 6 s timeout, so endless loops can't freeze the app.
- "By Veekshith" watermark on every screen.
- Original app icon restored.

## Build the APK through GitHub

1. Create a new GitHub repository.
2. Upload the contents of this `SnakeByte_Android_Project` folder to the repository root.
3. Open **Actions** → **Build SnakeByte APK**.
4. Run it with **Run workflow**, or push to `main`/`master`.
5. After the workflow finishes, open the run and download the **SnakeByte-debug-apk** artifact.
6. Extract the artifact and install `app-debug.apk` on Android.

### Local Android Studio build
Open the project root in Android Studio and run:
`gradle assembleDebug`

The APK will be at:
`app/build/outputs/apk/debug/app-debug.apk`

The Python runner still loads Pyodide from the internet, so coding execution requires internet access.
